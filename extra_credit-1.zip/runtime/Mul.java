package runtime;

public class Mul extends Instruction {
  
	Mul(int code, String mnemonic) {
		super(code,mnemonic);
	}
	
	
}
