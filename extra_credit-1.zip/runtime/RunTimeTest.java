package runtime;

import static org.junit.Assert.assertEquals;

import java.util.EmptyStackException;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class RunTimeTest {
	
	@Test
	public void testRunTime1() {
		Runtime test = new Runtime();
		test.readFromFile("eg1.pgm");
		test.run();
		assertEquals(test.toString(), "Pgm   : [push 5.0, push 3.4567, add, pop m0, exit]\nPc    : 6\nStack : []\nMemory: [8.4567, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]\n------------------------------------------------\n");
	}
	@Test
	public void testRunTime2() {
		Runtime test = new Runtime();
		test.readFromFile("eg2.pgm");
		test.run();
		assertEquals(test.toString(), "Pgm   : [push 5.0, pop m0, push m0, push m0, label l2, dec, jmpz done, pop m0, push m0, mul, push m0, jmp l2, label done, pop m0, exit]\nPc    : 16\nStack : [120.0]\nMemory: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]\n------------------------------------------------\n");
	}
	
	@Test
	public void testRunTime3() {
		Runtime test = new Runtime();
		test.readFromFile("eg3.pgm");
		Assertions.assertThrows(EmptyStackException.class, () -> test.run());
	}
	
	@Test
	public void testRunTime6() {
		Runtime test = new Runtime();
		test.readFromFile("eg6.pgm");
		test.run();
		assertEquals(test.toString(), "Pgm   : [push 4.0, push 2.4567, sub, pop m0, exit]\nPc    : 6\nStack : []\nMemory: [-1.5433, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]\n------------------------------------------------\n");
	}
	@Test
	public void testRunTime7() {
		Runtime test = new Runtime();
		test.readFromFile("eg7.pgm");
		test.run();
		assertEquals(test.toString(), "Pgm   : [push 3.0, push 4.0, mul, pop m0, exit]\nPc    : 6\nStack : []\nMemory: [12.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]\n------------------------------------------------\n");
	}

}
